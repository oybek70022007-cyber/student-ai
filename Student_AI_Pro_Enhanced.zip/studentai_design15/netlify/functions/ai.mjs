// Server tomonda Groq'ga so'rov yuboradi. Kalitlar faqat Netlify Environment variables ichida.
// Kerakli: GROQ_API_KEY. Ixtiyoriy: GROQ_MODEL, SUPABASE_URL, SUPABASE_ANON_KEY (kirishni tekshirish uchun).
const json = (o, s = 200) =>
  new Response(JSON.stringify(o), { status: s, headers: { "Content-Type": "application/json" } });

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Faqat POST so'rov qabul qilinadi" }, 405);
  const key = process.env.GROQ_API_KEY;
  if (!key) return json({ error: "Serverda GROQ_API_KEY sozlanmagan" }, 500);

  const su = process.env.SUPABASE_URL, sk = process.env.SUPABASE_ANON_KEY;
  if (su && sk) {
    const token = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
    if (!token) return json({ error: "Avval tizimga kiring" }, 401);
    try {
      const r = await fetch(su.replace(/\/$/, "") + "/auth/v1/user", {
        headers: { apikey: sk, Authorization: "Bearer " + token },
      });
      if (!r.ok) return json({ error: "Sessiya yaroqsiz. Qayta kiring" }, 401);
    } catch {
      return json({ error: "Autentifikatsiyani tekshirib bo'lmadi" }, 502);
    }
  }

  let b;
  try { b = await req.json(); } catch { return json({ error: "Noto'g'ri so'rov" }, 400); }
  const msgs = Array.isArray(b.messages) ? b.messages : null;
  if (!msgs || !msgs.length || msgs.length > 12) return json({ error: "messages noto'g'ri" }, 400);
  const clean = msgs.map((m) => ({
    role: ["system", "user", "assistant"].includes(m.role) ? m.role : "user",
    content: String(m.content || "").slice(0, 60000),
  }));

  const payload = {
    model: process.env.GROQ_MODEL || "llama-3.3-70b-versatile",
    messages: clean,
    temperature: Math.min(Math.max(Number(b.temperature) || 0.6, 0), 1.2),
    max_tokens: Math.min(Math.max(Number(b.max_tokens) || 3000, 100), 8000),
  };
  if (b.json) payload.response_format = { type: "json_object" };

  try {
    const r = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: "Bearer " + key },
      body: JSON.stringify(payload),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) return json({ error: d?.error?.message || "Groq xatosi " + r.status }, r.status === 429 ? 429 : 502);
    return json({ text: d.choices?.[0]?.message?.content || "" });
  } catch (e) {
    return json({ error: "Groq bilan ulanib bo'lmadi" }, 502);
  }
};
